import os
from dotenv import load_dotenv
from typing import List, Any
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_experimental.text_splitter import SemanticChunker
from sentence_transformers import SentenceTransformer
import numpy as np

load_dotenv()

class EmbeddingPipeline:
    def __init__(
        self,
        model_name: str = "BAAI/bge-m3",
        chunk_size: int = 700,
        chunk_overlap: int = 120,
    ):
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        self.model_name = model_name
        
        # Load HF Token
        hf_token = os.getenv("HUGGINGFACE_TOKEN") 

        if hf_token:
            os.environ["HUGGINGFACE_TOKEN"] = hf_token
            print("[INFO] Hugging Face token loaded successfully")
        else:
            print("[WARNING] HUGGINGFACE_TOKEN not found in .env file. Some models may fail to load.")

        print(f"[INFO] Loading embedding model: {model_name}")
        
        # Correct modern way to pass token
        self.model = SentenceTransformer(
            model_name,
            token=hf_token,                   
            trust_remote_code=True
        )
        
        print(f"[SUCCESS] Successfully loaded {model_name}")

    def chunk_documents(self, documents: List[Any]) -> List[Any]:
        """Advanced chunking logic"""
        all_chunks = []

        for doc in documents:
            try:
                semantic_splitter = SemanticChunker(
                    self.model, 
                    breakpoint_threshold_type="percentile",
                    breakpoint_threshold_amount=85,
                )
                semantic_chunks = semantic_splitter.split_documents([doc])
            except:
                semantic_chunks = []

            recursive_splitter = RecursiveCharacterTextSplitter(
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
                separators=["\n\n", "\n", ". ", "?", "!", " ", ""],
                keep_separator=True,
            )
            recursive_chunks = recursive_splitter.split_documents([doc])

            final_chunks = semantic_chunks if len(semantic_chunks) >= 3 else recursive_chunks
            all_chunks.extend(final_chunks)

        all_chunks = [c for c in all_chunks if len(c.page_content.strip()) > 70]
        print(f"[INFO] Chunking complete: {len(all_chunks)} chunks")
        return all_chunks

    def embed_chunks(self, chunks: List[Any]) -> np.ndarray:
        texts = [chunk.page_content for chunk in chunks]
        print(f"[INFO] Generating embeddings for {len(texts)} chunks...")

        embeddings = self.model.encode(
            texts,
            show_progress_bar=True,
            normalize_embeddings=True,
            batch_size=32
        )
        return embeddings
    
    def embed_query(self, query: str):

        embedding = self.model.encode(
            query,
            normalize_embeddings=True
        )
        return embedding.tolist()
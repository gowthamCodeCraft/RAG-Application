import os
import traceback
from dotenv import load_dotenv

from src.vector_store import PineconeHybridVectorStore
from src.advanced_rag import AdvancedRag
from langchain_groq import ChatGroq

load_dotenv()


class RAGSearch:
    def __init__(
        self,
        index_name: str = "rag-hybrid-index",
        embedding_model: str = "BAAI/bge-m3",
        llm_model: str = "llama3-70b-8192",
    ):

        print("\n========== RAGSearch INIT ==========")

        self.index_name = index_name
        self.embedding_model = embedding_model
        self.llm_model = llm_model

        # VECTOR STORE
        print("[INIT] Loading vector store...")
        self.vector_store = PineconeHybridVectorStore(
            index_name=index_name,
            embedding_model=embedding_model,
        )

        # LLM
        groq_api_key = os.getenv("GROQ_API_KEY")

        if groq_api_key:
            print("[INIT] Loading LLM...")
            self.llm = ChatGroq(
                groq_api_key=groq_api_key,
                model_name=llm_model,
                temperature=0.3,
                max_tokens=1024,
            )
            print(f"[SUCCESS] LLM initialized: {llm_model}")
        else:
            self.llm = None
            print("[WARNING] GROQ_API_KEY not found")

        # RAG STATE
        self.rag = None
        self.is_ready = False

        print("[SUCCESS] RAGSearch initialized")
        print("====================================\n")

    # =========================
    # INITIALIZATION
    # =========================
    def initialize_vector_store(self, documents=None):

        print("\n========== INITIALIZING RAG ==========")

        if self.is_ready:
            print("[DEBUG] Already initialized — skipping rebuild")
            return True

        try:
            if not documents:
                print("[ERROR] No documents provided")
                return False

            print(f"[INFO] Building index with {len(documents)} documents...")

            # Build vector store
            self.vector_store.build_from_documents(documents)

            print("[INFO] Vector store built successfully")

            # IMPORTANT: pass retriever (NOT vector_store)
            print("[INFO] Creating AdvancedRag pipeline...")

            self.rag = AdvancedRag(
                self.vector_store.retriever,
                self.llm
            )

            self.is_ready = True

            print("[SUCCESS] RAG system ready")
            print("====================================\n")

            return True

        except Exception as e:
            print("\n========== INIT ERROR ==========")
            traceback.print_exc()
            print("================================\n")

            self.is_ready = False
            return False

    # =========================
    # QUERY PIPELINE
    # =========================
    def query(
        self,
        question: str,
        top_k: int = 5,
        stream: bool = False,
        summarize: bool = False,
    ):

        print("\n========== QUERY REQUEST ==========")
        print(f"Question: {question}")
        print(f"Top_k: {top_k}, Stream: {stream}")
        print("==================================\n")

        if not self.is_ready or not self.rag:
            return {
                "answer": "System not ready. Please upload documents first.",
                "sources": [],
                "retrieved_count": 0,
            }

        try:
            print("[STEP 1] Sending query to AdvancedRag")

            result = self.rag.query(
                question=question,
                top_k=top_k,
                stream=stream,
                summarize=summarize,
            )

            print("[STEP 2] AdvancedRag returned:", type(result))

            return result

        except Exception as e:
            print("\n========== QUERY ERROR ==========")
            traceback.print_exc()
            print("================================\n")

            return {
                "answer": f"Error while processing query: {str(e)}",
                "sources": [],
                "retrieved_count": 0,
            }

    # =========================
    # REBUILD PIPELINE
    # =========================
    def rebuild_vector_store(self, documents):

        print("\n========== REBUILD REQUEST ==========")

        try:
            self.is_ready = False

            success = self.initialize_vector_store(documents)

            print("[INFO] Rebuild status:", success)

            return success

        except Exception as e:
            print("\n========== REBUILD ERROR ==========")
            traceback.print_exc()
            print("================================\n")

            return False
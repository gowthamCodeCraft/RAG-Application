from typing import List, Dict, Any, Optional

class AdvancedRag:
    def __init__(self, retriever, llm):
        print("[INFO] Initializing AdvancedRag...")
        self.retriever = retriever
        self.llm = llm
        self.history: List[Dict[str, Any]] = []

    # ================= SAFE EXTRACTOR =================
    def _extract(self, doc):
        """
        Safely extract content + metadata from:
        - dict
        - LangChain Document
        """

        if isinstance(doc, dict):
            return doc.get("content", ""), doc.get("metadata", {})

        # LangChain Document object
        content = getattr(doc, "page_content", "")
        metadata = getattr(doc, "metadata", {})

        return content, metadata

    # ================= DEDUPLICATION =================
    def _deduplicate(self, docs: List[Any]) -> List[Any]:
        seen = set()
        unique = []

        for doc in docs:
            _, metadata = self._extract(doc)

            key = (
                metadata.get("source_file", ""),
                metadata.get("page", ""),
            )

            if key not in seen:
                seen.add(key)
                unique.append(doc)

        return unique

    # ================= QUERY =================
    def query(self,question: str,top_k: int = 5,min_score: float = 0.0,stream: bool = False,summarize: bool = False,) -> Dict[str, Any]:

        print("\n==============================")
        print("[AdvancedRag.query STARTED]")
        print("Question:", question)
        print("==============================\n")

        try:
            print("[STEP 1] Starting retrieval")

            docs = self.retriever.get_relevant_documents(question)

            print(f"[STEP 2] Retrieved {len(docs)} docs")

            for i, doc in enumerate(docs[:3]):

                print(f"\n[DOC {i}]")
                print(doc.page_content[:300])

            retrieved_docs = self._deduplicate(retrieved_docs)

            # NO DOCS 
            if not retrieved_docs:
                return {
                    "answer": "I don't have enough information in the uploaded documents.",
                    "sources": [],
                    "retrieved_count": 0,
                }

            # BUILD CONTEXT
            context_parts = []
            sources = []

            for doc in retrieved_docs:
                content, metadata = self._extract(doc)

                context_parts.append(content)

                sources.append({
                    "source": metadata.get("source_file", metadata.get("source", "unknown")),
                    "page": metadata.get("page", "N/A"),
                    "score": metadata.get("relevance_score", 0.75),
                    "preview": content[:150] + "...",
                })

            context = "\n\n".join(context_parts)

            # PROMPT
            prompt = f"""
You are a precise AI assistant.
Answer ONLY using the provided context.

If answer is not in context, say:
"I don't have sufficient information to answer this."

Context:
{context}

Question:
{question}

Answer:
"""

            # LLM
            if stream:
                answer_chunks = []
                for chunk in self.llm.stream([prompt]):
                    token = chunk.content if hasattr(chunk, "content") else str(chunk)
                    print(token, end="", flush=True)
                    answer_chunks.append(token)
                answer = "".join(answer_chunks)
            else:
                response = self.llm.invoke([prompt])
                answer = response.content if hasattr(response, "content") else str(response)

            # CITATIONS
            citations = [
                f"[{i+1}] {s['source']} (Page {s['page']}) - Score: {s['score']}"
                for i, s in enumerate(sources)
            ]

            answer_with_citations = answer + "\n\nCitations:\n" + "\n".join(citations)

            # SUMMARY
            summary = None
            if summarize:
                summary_prompt = f"Summarize this in 2 lines:\n{answer}"
                summary_resp = self.llm.invoke([summary_prompt])
                summary = summary_resp.content if hasattr(summary_resp, "content") else str(summary_resp)

            # HISTORY 
            self.history.append({
                "question": question,
                "answer": answer,
                "sources": sources,
                "summary": summary,
            })

            return {
                "question": question,
                "answer": answer_with_citations,
                "sources": sources,
                "summary": summary,
                "history": self.history,
                "retrieved_count": len(retrieved_docs),
            }

        except Exception as e:
            print(f"[ERROR] AdvancedRag failed: {e}")
            return {
                "answer": "Internal error occurred during retrieval.",
                "sources": [],
                "retrieved_count": 0,
            }
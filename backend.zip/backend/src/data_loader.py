from pathlib import Path
from typing import List, Any
from langchain_community.document_loaders import (
    PyMuPDFLoader,
    TextLoader,
    CSVLoader,
    Docx2txtLoader,
    UnstructuredExcelLoader,
    JSONLoader,
)

def load_all_docs(data_dir: str = "data/uploads") -> List[Any]:
    """
    Load all supported documents from the directory and subdirectories.
    Improved version with better error handling and logging.
    """
    data_path = Path(data_dir).resolve()
    print(f"[INFO] Loading documents from: {data_path}")

    all_docs = []
    supported_extensions = {".pdf", ".txt", ".docx", ".xlsx", ".csv", ".json"}

    # Scan all files
    all_files = list(data_path.glob("**/*"))
    print(f"[INFO] Found {len(all_files)} total files. Processing supported formats...")

    for file_path in all_files:
        if file_path.is_file() and file_path.suffix.lower() in supported_extensions:
            try:
                loader = None
                ext = file_path.suffix.lower()

                if ext == ".pdf":
                    loader = PyMuPDFLoader(str(file_path))
                elif ext == ".txt":
                    loader = TextLoader(str(file_path), encoding="utf-8")
                elif ext == ".docx":
                    loader = Docx2txtLoader(str(file_path))
                elif ext == ".csv":
                    loader = CSVLoader(str(file_path))
                elif ext == ".xlsx":
                    loader = UnstructuredExcelLoader(str(file_path), mode="elements")
                elif ext == ".json":
                    loader = JSONLoader(
                        str(file_path),
                        jq_schema=".[]", 
                        text_content=False
                    )

                if loader:
                    loaded_docs = loader.load()
                    print(f"[SUCCESS] Loaded {len(loaded_docs)} docs from {file_path.name}")
                    all_docs.extend(loaded_docs)

            except Exception as e:
                print(f"[ERROR] Failed to load {file_path.name}: {e}")

    print(f"[INFO] Total documents loaded: {len(all_docs)}")
    return all_docs
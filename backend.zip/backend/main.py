import os
import shutil

#FIX WINDOWS ENCODING ISSUE (IMPORTANT)
os.environ["PYTHONUTF8"] = "1"
os.environ["PYTHONIOENCODING"] = "utf-8"

from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from src.search import RAGSearch
from src.data_loader import load_all_docs

app = FastAPI(title="Advanced RAG API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

chat_rag = RAGSearch()

class QueryRequest(BaseModel):
    query: str
    top_k: int = 5


@app.get("/")
async def root():
    return {"message": "RAG API running", "status": "healthy"}


# ================= UPLOAD =================
@app.post("/api/upload")
async def upload_document(file: UploadFile = File(...)):
    allowed = {".pdf", ".docx", ".txt", ".csv", ".xlsx"}

    if not any(file.filename.lower().endswith(ext) for ext in allowed):
        raise HTTPException(status_code=400, detail="Unsupported file type")

    os.makedirs("data/uploads", exist_ok=True)
    path = f"data/uploads/{file.filename}"

    with open(path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    try:
        docs = load_all_docs("data/uploads")

        # BUILD INDEX ONLY HERE (NO OTHER PLACE)
        chat_rag.vector_store.build_from_documents(docs)

        # rebuild RAG pipeline
        from src.advanced_rag import AdvancedRag
        chat_rag.rag = AdvancedRag(chat_rag.vector_store.retriever, chat_rag.llm)
        chat_rag.is_ready = True

        return {"message": "File uploaded & index built successfully"}

    except Exception as e:
        return {"message": f"Upload done but indexing failed: {str(e)}"}


# ================= QUERY =================
@app.post("/api/query")
async def query_document(request: QueryRequest):

    # DO NOT auto-initialize here (IMPORTANT FIX)
    if not chat_rag.is_ready:
        return {
            "answer": "System not ready. Please upload documents first.",
            "sources": []
        }

    return chat_rag.query(request.query, top_k=request.top_k)


import traceback

@app.post("/api/query-stream")
async def query_stream(request: QueryRequest):

    query = request.query

    print("\n============================")
    print("[STREAM API CALLED]")
    print("Query:", query)
    print("============================\n")

    if not query:
        raise HTTPException(400, "Query required")

    def generate():

        try:
            print("[STEP 1] Calling chat_rag.query()")

            result = chat_rag.query(
                question=query,
                stream=True
            )

            print("[STEP 2] query() returned:", type(result))

            # CASE 1 → dict response
            if isinstance(result, dict):

                print("[STEP 3] Dict response received")

                yield result.get("answer", "")

            # CASE 2 → generator / streaming
            elif hasattr(result, "__iter__"):

                print("[STEP 3] Streaming generator detected")

                for chunk in result:

                    print("[STREAM CHUNK]", chunk)

                    yield str(chunk)

            else:

                print("[STEP 3] Normal response")

                yield str(result)

        except Exception as e:

            print("\n========== FULL ERROR ==========")

            traceback.print_exc()

            print("================================\n")

            yield f"[ERROR] {str(e)}"

    return StreamingResponse(
        generate(),
        media_type="text/plain"
    )

# ====================== VOICE QUERY ======================
@app.post("/api/voice-query")
async def voice_query(file: UploadFile = File(...)):
    if not file.filename.lower().endswith((".wav", ".mp3", ".m4a", ".ogg")):
        raise HTTPException(status_code=400, detail="Only audio files supported")

    os.makedirs("temp", exist_ok=True)
    audio_path = f"temp/{file.filename}"

    with open(audio_path, "wb") as f:
        shutil.copyfileobj(file.file, f)

    try:
        from groq import Groq

        client = Groq(api_key=os.getenv("GROQ_API_KEY"))

        with open(audio_path, "rb") as audio:
            transcription = client.audio.transcriptions.create(
                file=audio,
                model="whisper-large-v3",
                response_format="json"
            )

        text = transcription.text

        # ❗ SAFE CHECK (important after refactor)
        if not chat_rag.is_ready:
            return {
                "transcribed_text": text,
                "answer": "System not ready. Please upload documents first.",
                "sources": []
            }

        result = chat_rag.query(text)

        return {
            "transcribed_text": text,
            **result
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Voice processing failed: {str(e)}")
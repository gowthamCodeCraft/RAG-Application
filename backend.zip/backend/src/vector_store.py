import os
from typing import List, Any, Dict

from pinecone import Pinecone
from pinecone_text.sparse import BM25Encoder

from langchain_community.retrievers import PineconeHybridSearchRetriever
from langchain_classic.retrievers.document_compressors import CrossEncoderReranker
from langchain_classic.retrievers.contextual_compression import ContextualCompressionRetriever
from langchain_community.cross_encoders import HuggingFaceCrossEncoder
from langchain_huggingface import HuggingFaceEmbeddings

from src.embedding import EmbeddingPipeline


class PineconeHybridVectorStore:
    """
    TRUE Hybrid Search Vector Store:
    Dense + Sparse + Reranking (correct Pinecone implementation)
    """

    def __init__(
        self,
        index_name: str = "rag-hybrid-index",
        embedding_model: str = "BAAI/bge-m3",
        chunk_size: int = 700,
        chunk_overlap: int = 120,
    ):
        self.index_name = index_name
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

        # Pinecone client + index (IMPORTANT FIX)
        self.pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))
        self.index = self.pc.Index(self.index_name)

        # Embeddings
        self.embeddings = HuggingFaceEmbeddings(
            model_name=embedding_model,
            model_kwargs={"token": os.getenv("HF_TOKEN")},
            encode_kwargs={"normalize_embeddings": True},
        )

        # Chunking pipeline
        self.embedding_pipeline = EmbeddingPipeline(
            model_name=embedding_model,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

        # Sparse encoder
        self.sparse_encoder = BM25Encoder()

        self.retriever = None

        print(f"[INFO] Pinecone Hybrid Vector Store initialized: {embedding_model}")

    # BUILD HYBRID INDEX (FIXED)
    def build_from_documents(self, documents):

        print(f"[INFO] Building index from {len(documents)} docs")

        chunks = self.embedding_pipeline.chunk_documents(documents)

        if not chunks:
            raise ValueError("No chunks generated")

        texts = [c.page_content for c in chunks]

        self.sparse_encoder.fit(texts)

        batch = []

        for i, chunk in enumerate(chunks):

            dense = self.embeddings.embed_query(chunk.page_content)
            sparse = self.sparse_encoder.encode_documents([chunk.page_content])[0]

            batch.append({
                "id": f"chunk-{i}",
                "values": dense,
                "sparse_values": sparse,
                "metadata": {
                    **(chunk.metadata or {}),
                    "text": chunk.page_content
                }
            })

        self.index.upsert(vectors=batch)

        print(f"[SUCCESS] Indexed {len(batch)} chunks")

        # retriever build
        hybrid_retriever = PineconeHybridSearchRetriever(
            embeddings=self.embeddings,
            sparse_encoder=self.sparse_encoder,
            index=self.index,
            top_k=10,
            alpha=0.65,
        )

        reranker = CrossEncoderReranker(
            model=HuggingFaceCrossEncoder(
                model_name="BAAI/bge-reranker-large",
                model_kwargs={"token": os.getenv("HF_TOKEN")},
            ),
            top_n=5,
        )

        self.retriever = ContextualCompressionRetriever(
            base_compressor=reranker,
            base_retriever=hybrid_retriever,
        )

        print("[SUCCESS] Hybrid retriever ready")
        return self.retriever

    
    # RETRIEVE
    def retrieve(self, query: str, top_k: int = 5, score_threshold: float = 0.0) -> List[Dict]:
        if not self.retriever:
            raise ValueError("Retriever not initialized. Call build_from_documents() first.")

        print(f"[INFO] Querying hybrid index: {query}")

        docs = self.retriever.invoke(query)

        results = []

        for i, doc in enumerate(docs[:top_k]):
            score = doc.metadata.get("relevance_score", 0.75)

            if score < score_threshold:
                continue

            results.append({
                "id": i,
                "content": doc.page_content,
                "metadata": doc.metadata,
                "similarity_score": float(score),
                "rank": i + 1
            })

        print(f"[INFO] Retrieved {len(results)} results")
        return results